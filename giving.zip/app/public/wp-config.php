<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'nvhYUETRxCTB9MkSau7wggmdKy8O/eGidSMnAQVQCrSyeaEBh0YFDxOXwUcTdQ6GPL7eq/yOJg/o3ag2HdOTww==');
define('SECURE_AUTH_KEY',  'c6qpYZ9gRTLlzHMdxu+fokWXX/7MuqwB8lc6hhe2JACVqXzSoFx2phepclahbN5tR07vwUJCNeDttyrq7Trqpg==');
define('LOGGED_IN_KEY',    'wSnVrLKbmi5e8gpxzEIP2aZlnRNVuSttQ0eOJaXEir8qtd7YuVLIyKgUDPDMhzga+3zocxi1/6Zh+FWfbglQiA==');
define('NONCE_KEY',        'jJ0bztGp0qzbQdgf+bX7+CamHbZsu6kBXqEXwC1JiS/BP1Yn+YizRm21xEUtOTZhAPJEL2Nhp/xT/XpOZitg9A==');
define('AUTH_SALT',        'JR/mFrHu5j7kwgn96/mwQNZE2PrtG//O88tfvq8IRnVsPPkhHiW2IU6bgsyKlrvecuaqNAUaJV6nvHrpCCyFcw==');
define('SECURE_AUTH_SALT', '+ohWOgIofAVm3m8hw/k661MMMhQDwv4Rfby+6Mban0ljgOvXNohDwX23hkJbPsaZ5HqouYW/pCon4065Q6A2GA==');
define('LOGGED_IN_SALT',   'fvEhIgNVO3Nf2nJjsJoDV/lt7PAizO+dlFwWtZELM1YC7hmP2g+ssvcy0uV2rIpS9qR85Wu/caxikSn9FfOrkA==');
define('NONCE_SALT',       'S2bEHevaDVhLJcRqSoecPi7dGn3rgTlzoIwpGwG1It5FnWmW0i36ld1h7E6v807GknkITWW3AfbcE0InFny9lw==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
